package org.carlos.clashtournament.clases;

import org.carlos.clashtournament.bean.Clan;


public class Clanes {
    public static Clan clan = null;

    public static void setClan(Clan c){
        clan = c;
    }

    public static Clan getClan(){
        return clan;
    }

}
