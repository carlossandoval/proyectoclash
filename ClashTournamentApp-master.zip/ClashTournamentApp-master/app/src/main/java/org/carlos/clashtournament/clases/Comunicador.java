package org.carlos.clashtournament.clases;

import org.carlos.clashtournament.bean.Usuario;


public class Comunicador {
    private static Usuario usuario = null;

    public static void setUsuario(Usuario _usuario){
        usuario = _usuario;
    }
    public static Usuario getUsuario(){
        return usuario;
    }
}
