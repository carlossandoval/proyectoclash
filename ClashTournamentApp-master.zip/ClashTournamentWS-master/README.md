# ClashTournamentWS
WebService en PHP para ClashTournament
