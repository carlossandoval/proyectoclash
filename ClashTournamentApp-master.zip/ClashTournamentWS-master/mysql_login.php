<?php
/**
 * Provee las constantes para conectarse a la base de datos
 * Mysql.
 */
define("HOSTNAME", "mysql1.000webhost.com");// Nombre del host
define("DATABASE", "a6700695_ct"); // Nombre de la base de datos
define("USERNAME", "a6700695_jeff"); // Nombre del usuario
define("PASSWORD", "43353780jefrien"); // Nombre de la constraseÃ±a
?>