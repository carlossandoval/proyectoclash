<?php
/**
 * Insertar una nueva meta en la base de datos
 */

require 'Clan.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Decodificando formato Json
    $body = json_decode(file_get_contents("php://input"), true);
	$verifico = Clan::existe($body['nombre']);
	if($verifico){
		// Código de existe
        print json_encode(
            array(
                'estado' => '2',
                'mensaje' => 'Nombre no disponible!')
        );
	} else {
    // Insertar meta
    $retorno = Clan::insert(
        $body['nombre'],
        $body['integrantes'],
		$body['idUsuario']);

    if ($retorno) {
        // Código de éxito
		// Tratar retorno
        $resClan = Clan::getByName(
			$body['nombre']
		);
		
		$clan["estado"] = "1";
		$clan["mensaje"] = "Clan creado correctamente";
		$clan["clan"] = $resClan;
		
        print json_encode($clan);
    } else {
        // Código de falla
        print json_encode(
            array(
                'estado' => '2',
                'mensaje' => 'Error creando el clan')
        );
    }
	}
}
?>