<?php
/**
 * Insertar una nueva meta en la base de datos
 */

require 'Usuario.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Decodificando formato Json
    $body = json_decode(file_get_contents("php://input"), true);
	$verifico = Usuario::existe($body['usuario']);
	if($verifico){
		// Código de existe
        print json_encode(
            array(
                'estado' => '2',
                'mensaje' => 'Usuario ya existente')
        );
	} else {
    // Insertar meta
    $retorno = Usuario::insert(
        $body['usuario'],
        $body['password'],
		$body['nombre']);

    if ($retorno) {
        // Código de éxito
        print json_encode(
            array(
                'estado' => '1',
                'mensaje' => 'Registrado correctamente')
        );
    } else {
        // Código de falla
        print json_encode(
            array(
                'estado' => '2',
                'mensaje' => 'Registro incorrecto')
        );
    }
	}
}
?>