<?php
/**
 * Insertar una nueva meta en la base de datos
 */

require 'Usuario.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Decodificando formato Json
    $body = json_decode(file_get_contents("php://input"), true);
	$verifico = Usuario::existe($body['usuario']);
	if($verifico){
		
		$retorno = Usuario::addClan(
			$body['idUsuario'],
			$body['clan']
		);
		
		 if ($retorno) {
        // Código de éxito
        print json_encode(
            array(
                'estado' => '1',
                'mensaje' => 'Te uniste al clan')
        );
    } else {
        // Código de falla
        print json_encode(
            array(
                'estado' => '2',
                'mensaje' => 'No puedes unirte al clan')
        );
		
	} 
	} else {
        // Código de falla
        print json_encode(
            array(
                'estado' => '2',
                'mensaje' => 'No existe el clan')
        );
    }
	
}
?>